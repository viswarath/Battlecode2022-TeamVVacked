package VVacked;


import battlecode.common.*;

public class Watchtower {
    
}