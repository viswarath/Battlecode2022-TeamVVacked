package VVacked;


import battlecode.common.*;

public class Builder {
    static void run(RobotController rc){

    }
}
