package VVacked;


public class Laboratory {
    
}
